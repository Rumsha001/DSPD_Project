from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import pickle
import pandas as pd
import os

from helpers import load_model_from_s3, get_all_files, get_weather_csvs_from_S3, lstm_prediction, load_model_from_disk

APP_ROOT = os.path.dirname(os.path.realpath(__file__))
MODEL_PATH = '/'.join([APP_ROOT, 'model.pkl'])#for prophet
templates = Jinja2Templates(directory=f'{APP_ROOT}/templates')
# load all bucket objects again including the new ones created when we called make_csv_for_weather()
get_all_files()
dataset, is_exist = get_weather_csvs_from_S3()
load_model_from_s3('model_lstm.json')
load_model_from_s3('model_lstm.h5')
lstm_model = load_model_from_disk()
_5_days = lstm_prediction(lstm_model, dataset)
app = FastAPI()


@app.get("/", response_class=HTMLResponse)
def read_root():
    return "Use /prophet/{date} for prediction"


@app.get("/prophet/{date}", response_class=HTMLResponse)
def predict_prophet(request: Request, date: str):
    prediction = get_prediction(date)
    context = {'request': request, 'table': prediction}
    return templates.TemplateResponse('prediction.html', context)


def get_prediction(date):
    loaded_model = pickle.load(open(MODEL_PATH, 'rb'))
    future = list()
    future.append(date)
    # for i in range(1, 13):
    #     date = '2021-%02d' % i
    #     future.append([date])
    future = pd.DataFrame(future)
    future.columns = ['ds']
    future['ds'] = pd.to_datetime(future['ds'])
    print(future)
    res = loaded_model.predict(future)
    print(res)
    html_updated = res.to_html(classes=["table", "table-hover", "table-responsive"])
    print(html_updated)
    return html_updated


@app.get('/lstm', response_class=HTMLResponse)
def get_lstm_prediction(request: Request):
    print(dataset.tail(1))
    print(_5_days)
    lstm_obj = {"predData": _5_days}
    context = {'request': request, 'lstm_obj': lstm_obj}
    return templates.TemplateResponse('prediction.html', context)
