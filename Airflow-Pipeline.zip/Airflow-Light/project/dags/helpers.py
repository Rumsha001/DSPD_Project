import requests
import calendar
import pandas as pd
import pandas as pd
from io import StringIO
import datetime
import boto3

aws_client = {"key": "AKIAXOC55QCQVVE62DUU", "secret": "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",
              "region": "us-east-2"}  # user has full access to S3Buckets Only, username:s3bucketuser
s3 = boto3.session.Session().resource("s3",
                                      aws_access_key_id=aws_client["key"],
                                      aws_secret_access_key=aws_client["secret"],
                                      region_name=aws_client["region"]
                                      )

bucket_name = 'dspd-project-weather-csv-database'
folder = 'weathercsv/'
model_folder = 'models/'
bucket = s3.Bucket(bucket_name)
file_obj_list = []
labels = [
    'time', 'tempC', 'windspeedMiles', 'windspeedKmph', 'winddirDegree', 'winddir16Point', 'weatherCode', 'precipMM',
    'FeelsLikeC', 'humidity', 'pressure', 'DewPointC'
]


def get_weather_csvs_from_S3():
    global s3, bucket, folder, file_obj_list
    dataframes = []
    for file in file_obj_list:
        if file.key == folder:
            continue
        dataframes.append(s3_obj_to_df(file))

    return (pd.concat(dataframes), True) if len(dataframes) > 0 else (pd.DataFrame(), False)


def s3_obj_to_df(obj):
    bytes_data = obj.get()['Body'].read()
    s = str(bytes_data, 'utf-8')
    data = StringIO(s)
    df = pd.read_csv(data)
    return df


def is_file_exist_in_s3(year):
    global folder, file_obj_list
    curr_year = datetime.datetime.now().year
    print(curr_year, year)
    if curr_year == year:
        return False

    path = f'{folder}{year}.csv'
    if any([w.key == path for w in file_obj_list]):
        return True
    else:
        return False


def get_all_files():
    global s3, bucket, folder, bucket_name, file_obj_list
    file_obj_list = []
    for file in bucket.objects.filter(Prefix=folder):
        if file.key == folder:
            continue
        file_obj_list.append(file)


def create_csv_in_s3(df, year):
    global s3, bucket_name, folder
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False)
    s3.Object(bucket_name, f'{folder}{year}.csv').put(Body=csv_buffer.getvalue())


def upload_file_to_s3(file, file_name):
    global s3, bucket_name, folder, model_folder
    return s3.Object(bucket_name, f'{model_folder}{file_name}').put(Body=file)


def parse_hourly_obj(obj, w_date):
    hour_obj = {}
    hour_obj['date'] = w_date
    for label in labels:
        hour_obj[label] = obj[label]

    return hour_obj


def get_data_world_weather_online(from_date, to_date):
    url = "http://api.worldweatheronline.com/premium/v1/past-weather.ashx?"
    params = {
        "key": "86bce84f05b24ef2a9e202325210203",
        "q": "Karachi, Pakistan",
        "format": "json",
        "date": from_date,
        "enddate": to_date,
        "show_comments": "no",
        "tp": 1
    }
    response = requests.get(url=url, params=params)
    return response.json()


def get_monthly_date_range(year):
    month_range = []
    for i in range(1, 13):
        start_date = f"{year}-{i}-01"
        end_date = f"{year}-{i}-{calendar.monthlen(year, i)}"
        month_range.append({"start": start_date, "end": end_date})

    return month_range


def make_csv_for_weather(years):
    global file_obj_list
    results = []
    for year in years:
        if not is_file_exist_in_s3(year):
            months_range = get_monthly_date_range(year)
            for mon_range in months_range:
                response_json = get_data_world_weather_online(mon_range["start"], mon_range["end"])
                print(response_json)
                data = response_json["data"]
                if "weather" in data.keys():
                    weathers = data["weather"]
                    for weather in weathers:
                        hourly_data_objs = weather["hourly"]
                        w_date = weather["date"]
                        for hourly_obj in hourly_data_objs:
                            results.append(parse_hourly_obj(hourly_obj, w_date))
                if len(results) > 0:
                    df = pd.DataFrame(results)
                    # save to s3
                    s3_object = create_csv_in_s3(df, year)


        else:
            print(f"This File Already Exist: {year}.csv")


def make_files():
    years = [2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, datetime.datetime.now().year]
    # load all bucket objects in file_obj_list
    get_all_files()
    # csv will be stored in S3 if not already present
    make_csv_for_weather(years)
    # convert objects in file_obj_list to dataframe
    return get_weather_csvs_from_S3()


def date_to_timestamp(dataset):
    get_time = dataset['time']
    new_time = []
    for i in get_time:
        if (i == 0):
            i = "0000"
        new_time.append(str(i))

    dataset["date"] = pd.to_datetime(dataset["date"]).dt.strftime('%Y%m%d')  # not required
    newDate = dataset['date'] + new_time
    dataset['date'] = pd.to_datetime(newDate, format='%Y%d%m%H%M%S')
    dataset.rename(columns={"date": "datetime"}, inplace=True)
    dataset.drop(['time'], inplace=True, axis=1)
    return dataset


def push_model_to_s3(model, model_name):
    pass
