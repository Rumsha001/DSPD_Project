# Core Keras libraries
#
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from keras.layers import Bidirectional

#
# For data conditioning
#
from scipy.ndimage import gaussian_filter1d
from scipy.signal import medfilt

#
# Make results reproducible
#
from numpy.random import seed

seed(1)
import tensorflow

tensorflow.random.set_seed(1)
#
# Other essential libraries
#
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from numpy import array
from keras.models import model_from_json


#
# Split data into n_timestamp
#
def data_split(sequence, n_timestamp):
    X = []
    y = []
    for i in range(len(sequence)):
        end_ix = i + n_timestamp
        if end_ix > len(sequence) - 1:
            break
        # i to end_ix as input
        # end_ix as target output
        seq_x, seq_y = sequence[i:end_ix], sequence[end_ix]
        X.append(seq_x)
        y.append(seq_y)
    return array(X), array(y)


def preprocess(dataset):
    n_timestamp = 10
    train_days = 1500  # number of days to train from
    testing_days = 500  # number of days to be predicted
    n_epochs = 25
    filter_on = 1

    if filter_on == 1:
        dataset['tempC'] = medfilt(dataset['tempC'], 3)
        dataset['tempC'] = gaussian_filter1d(dataset['tempC'], 1.2)
        #
    # Set number of training and testing data
    #
    train_set = dataset[0:train_days].reset_index(drop=True)
    test_set = dataset[train_days: train_days + testing_days].reset_index(drop=True)
    print(test_set)
    training_set = train_set.iloc[:, 1:2].values
    testing_set = test_set.iloc[:, 1:2].values
    #
    # Normalize data first
    #
    sc = MinMaxScaler(feature_range=(0, 1))
    training_set_scaled = sc.fit_transform(training_set)
    testing_set_scaled = sc.fit_transform(testing_set)
    print(testing_set_scaled)

    X_train, y_train = data_split(training_set_scaled, n_timestamp)
    X_train = X_train.reshape(X_train.shape[0], X_train.shape[1], 1)
    X_test, y_test = data_split(testing_set_scaled, n_timestamp)
    X_test = X_test.reshape(X_test.shape[0], X_test.shape[1], 1)
    print(X_test)
    return {
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "sc": sc
    }


def compile_model(model_type, datasets):
    if model_type == 1:
        # Single cell LSTM
        model = Sequential()
        model.add(LSTM(units=50, activation='relu', input_shape=(datasets["X_train"].shape[1], 1)))
        model.add(Dense(units=1))

    if model_type == 2:
        # Stacked LSTM
        model = Sequential()
        model.add(LSTM(50, activation='relu', return_sequences=True, input_shape=(datasets["X_train"].shape[1], 1)))
        model.add(LSTM(50, activation='relu'))
        model.add(Dense(1))
    if model_type == 3:
        # Bidirectional LSTM
        model = Sequential()
        model.add(Bidirectional(LSTM(50, activation='relu'), input_shape=(datasets["X_train"].shape[1], 1)))
        model.add(Dense(1))
    return model


def train_lstm(model, hyperparams, datasets):
    #
    # Start training
    #
    model.compile(optimizer='adam', loss='mean_squared_error')
    history = model.fit(datasets["X_train"], datasets["y_train"], epochs=hyperparams["n_epochs"],
                        batch_size=hyperparams["batch_size"])
    loss = history.history['loss']
    epochs = range(len(loss))
    # save model
    save_model_to_disk(model)
    return model


def load_model_from_disk():
    # load json and create model
    json_file = open('model_lstm.json', 'r')
    loaded_model_json = json_file.read()
    json_file.close()
    loaded_model = model_from_json(loaded_model_json)
    # load weights into new model
    loaded_model.load_weights("model_lstm.h5")
    print("Loaded model from disk")
    return loaded_model


def save_model_to_disk(model):
    # serialize model to JSON
    model_json = model.to_json()
    with open("model_lstm.json", "w") as json_file:
        json_file.write(model_json)
    # serialize weights to HDF5
    model.save_weights("model_lstm.h5")
    print("Saved model to disk")



def make_predictions(model, datasets):
    #
    # Get predicted data
    #
    y_predicted = model.predict(datasets["X_test"])

    #
    # 'De-normalize' the data
    #
    y_predicted_descaled = datasets["sc"].inverse_transform(y_predicted)
    y_train_descaled = datasets["sc"].inverse_transform(datasets["y_train"])
    y_test_descaled = datasets["sc"].inverse_transform(datasets["y_test"])
    y_pred = y_predicted.ravel()
    y_pred = [round(yx, 2) for yx in y_pred]
    y_tested = datasets["y_test"].ravel()
    y_tested = [round(yx, 2) for yx in y_tested]
    mse = mean_squared_error(y_test_descaled, y_predicted_descaled)
    r2 = r2_score(y_test_descaled, y_predicted_descaled)
    print("mse=" + str(round(mse, 2)))
    print("r2=" + str(round(r2, 2)))
    print(y_predicted_descaled)
