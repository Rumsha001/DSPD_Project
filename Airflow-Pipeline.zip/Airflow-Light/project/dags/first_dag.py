try:

    from datetime import timedelta
    from airflow import DAG
    from airflow.operators.python_operator import PythonOperator
    import numpy as np
    import requests
    import json
    import os
    import glob
    import calendar
    import boto3
    import pandas as pd
    import pickle
    import datetime
    from helpers import *
    from model_helpers import *

    print("All Dag modules are ok ......")
except Exception as e   :
    print("Error  {} ".format(e))


def get_weather_data(**context):  # first step
    try:
        dataframe, is_exist = make_files()
        if is_exist:
            context['ti'].xcom_push(key='gotTheData', value=True)
            context['ti'].xcom_push(key='dataframe', value=dataframe)
    except e:
        context['ti'].xcom_push(key='gotTheData', value=False)

    print("Get Data From API")  # Get Data -- code colab notebook

    context['ti'].xcom_push(key='gotTheData', value=True)


def train_model(**context):  # second step
    from model_helpers import preprocess, compile_model, make_predictions, train_lstm

    got_the_data = context.get("ti").xcom_pull(key="gotTheData")
    if got_the_data == True:
        print("Got The Data")
        dataframe = context.get("ti").xcom_pull(key="dataframe")
        hyperparams = {
            "step": 3,
            "batch_size": 128,
            "n_epochs": 5,
            "learning_rate": 0.0001,
            "filter_on": 1
        }

        datasets = preprocess(date_to_timestamp(dataframe))
        model = compile_model(2, datasets)
        model = train_lstm(model, hyperparams, datasets)
        make_predictions(model, datasets)
        print(datasets)
        print(dataframe)
        print("model_trained")
        context['ti'].xcom_push(key='isModelTrained', value=True)


def push_model(**context): #third step
    is_model_trained = context.get("ti").xcom_pull(key="isModelTrained")
    # load save_model
    if is_model_trained == True:
        print("Pushing Model")
        # model = load_model_from_disk()
        # print(model)
        # push lstm model files to s3
        upload_file_to_s3(open('model_lstm.json', 'rb'), 'model_lstm.json')
        upload_file_to_s3(open('model_lstm.h5', 'rb'), 'model_lstm.h5')
        print('file uploaded to S3 Bucket')


with DAG(
        dag_id="first_dag",
        schedule_interval="@daily",
        default_args={
            "owner": "airflow",
            "retries": 1,
            "retry_delay": timedelta(minutes=5),
            "start_date": datetime.datetime(2021, 1, 1),
        },
        catchup=False) as f:
    get_weather_data = PythonOperator(
        task_id="get_weather_data",
        python_callable=get_weather_data,
        provide_context=True,
        op_kwargs={"name": "Sarosh"}
    )

    train_model = PythonOperator(
        task_id="train_model",
        python_callable=train_model,
        provide_context=True,
    )

    push_model = PythonOperator(
        task_id="push_model",
        python_callable=push_model,
        provide_context=True,
    )

get_weather_data >> train_model >> push_model
